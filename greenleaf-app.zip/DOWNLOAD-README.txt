﻿# GreenLeaf Organics app bundle

This folder contains the offline-capable storefront frontend. Serve these files from a web server to enable app installation and offline caching. Online API checkout and newsletter need the Node backend.
